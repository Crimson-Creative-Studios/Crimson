# Crimson

This is the base of the "Delta" bot in the Skyo Productions Discord server

You can install extensions using the built-in extension downloader, this will get extensions from any source you want but defaults to the main repo which is the Verified Crimson Extension Repo, these are verified by me and are **safe**, most will be from me however, I do accept community submissions though so don't be afraid to ask!

A wiki on how to make extensions will come soon

Some cool extensions to check out:
| Extension      | What it does   |
| -------------- | -------------- |
| PyRun          | PyRun is an extension that can allow other extensions to run Python code and return results with ease, this does nothing by itself but can be a powerful developer tool in the making of extensions, it allows **all** python modules to run but they must be installed on the system, this can be automated in PyRun soon |
| LinkBot        | LinkBot is an extension that can link 2 different channels in 2 different discord servers, users can communicate between servers, it also can transfer emojis, profile pictures, images and even if the other server has tag commands they can be used in a server without them, amazing right?
| Warped (WIP)   | Warped is a Minecraft server API, it allows users to ping a Minecraft server and get information out of the server, including if it's online or not, its MOTD and more... |
| Your extension | You can make your own extension too, if works just like Discord.JS, you make an index.js file and just start coding, put it into extension format and it will run (providing your code has no errors, if your code does then that isn't Crimson's fault). You are the owner of this bot, you decide what it does, not some big corporation (*cough cough Mee6*) |