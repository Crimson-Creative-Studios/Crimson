//Normally used for preloaded customization for more advanced users, rename the file to "themepreload.js" to use it


//!Title change
//document.getElementById("texttitle").innerHTML = "CrimsonGUI"

//!General theme items
//document.documentElement.style.setProperty('--background', '')
//document.documentElement.style.setProperty('--backgroundalt', '')
//document.documentElement.style.setProperty('--color', '')
//document.documentElement.style.setProperty('--coloralt', '')
//document.documentElement.style.setProperty('--button', '')
//document.documentElement.style.setProperty('--buttonhov', '')
//document.documentElement.style.setProperty('--buttonact', '')
//document.documentElement.style.setProperty('--buttonacthov', '')

//!Override
//document.getElementById("extensionThemeOverride").checked = true

//!Per button changes
//document.getElementById("OptionsButton").style.setProperty('--button', '')
//document.getElementById("OptionsButton").style.setProperty('--buttonhov', '')
//document.getElementById("OptionsButton").style.setProperty('--buttonact', '')
//document.getElementById("OptionsButton").style.setProperty('--buttonacthov', '')

//!Add to the credits
//document.getElementById("credits").innerHTML += `<p><a onclick="crimAPI.openSite('https://example.com/')">Example</a> - Example</p>`

//!Change button text inner
//document.documentElement.style.setProperty('--buttontext', '')

//!Recommended ending to load all colors properly
//loadColors()