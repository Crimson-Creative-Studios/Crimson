document.getElementById("texttitle").innerHTML = "CrimsonGUI - Dev Edition"
document.getElementById("extensionThemeOverride").checked = true

document.getElementById("backgroundmainchange").value = 'url("https://r4.wallpaperflare.com/wallpaper/707/220/899/gradient-blue-pink-abstract-art-wallpaper-a33b436d2de9cbc5dfa6225748ab3818.jpg")'
document.getElementById("backgroundaltchange").value = 'transparent'
document.getElementById("textmainchange").value = ""
document.getElementById("textaltchange").value = ""
document.getElementById("buttonmainchange").value = "black"
document.getElementById("buttonhovchange").value = "#222"
document.getElementById("buttonactchange").value = "#444"
document.getElementById("buttonhovactchange").value = "#666"

document.getElementById("backgroundmainchangel").value = 'url("https://r4.wallpaperflare.com/wallpaper/707/220/899/gradient-blue-pink-abstract-art-wallpaper-a33b436d2de9cbc5dfa6225748ab3818.jpg")'
document.getElementById("backgroundaltchangel").value = 'transparent'
document.getElementById("textmainchangel").value = "white"
document.getElementById("textaltchangel").value = "#c4c4c4"
document.getElementById("buttonmainchangel").value = "black"
document.getElementById("buttonhovchangel").value = "#222"
document.getElementById("buttonactchangel").value = "#444"
document.getElementById("buttonhovactchangel").value = "#666"
loadColors()

document.getElementById("OptionsButton").style.setProperty("--button", "black")
document.getElementById("OptionsButton").style.setProperty("--buttonhov", "#111")
document.getElementById("OptionsButton").style.setProperty("--buttonact", "#222")
document.getElementById("OptionsButton").style.setProperty("--buttonacthov", "#333")
document.getElementById("credits").innerHTML += `<p><a onclick="crimAPI.openSite('https://www.wallpaperflare.com/')">Wallpaper Flare</a> - Background</p>`