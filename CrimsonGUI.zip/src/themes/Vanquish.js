clearColor()

resetEl()

setBackgroundColor({
    main: "#293462",
    alt: "#242e59",
    console: ""
})

setButtonColor({
    main: "#ec9b3b",
    hover: "#f24c4c",
    active: "#d63c3c",
    hoveractive: "#ba3030",
    text: ""
})

loadColors()