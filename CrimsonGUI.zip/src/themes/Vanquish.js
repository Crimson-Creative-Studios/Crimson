clearColor()

document.getElementById("element").value = ""
document.getElementById("backgroundmainchange").value = "#293462"
document.getElementById("backgroundaltchange").value = "#242e59"
document.getElementById("textmainchange").value = "white"
document.getElementById("textaltchange").value = "#c4c4c4"
document.getElementById("buttonmainchange").value = "#ec9b3b"
document.getElementById("buttonhovchange").value = "#f24c4c"
document.getElementById("buttonactchange").value = "#d63c3c"
document.getElementById("buttonhovactchange").value = "#ba3030"
loadColors()