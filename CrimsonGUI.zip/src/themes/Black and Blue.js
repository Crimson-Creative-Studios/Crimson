clearColor()

document.getElementById("element").value = ""
document.getElementById("backgroundmainchange").value = "#0F64AC"
document.getElementById("backgroundaltchange").value = "#0a5391"
document.getElementById("textmainchange").value = "white"
document.getElementById("textaltchange").value = "#c4c4c4"
document.getElementById("buttonmainchange").value = "#000000"
document.getElementById("buttonhovchange").value = "#303030"
document.getElementById("buttonactchange").value = "#505050"
document.getElementById("buttonhovactchange").value = "#707070"
loadColors()