clearColor()

resetEl()

setBackgroundColor({
    main: "#0f64ac",
    alt: "#0e5fa3",
    console: ""
})

setButtonColor({
    main: "#000000",
    hover: "#303030",
    active: "#505050",
    hoveractive: "#707070",
    text: ""
})

loadColors()