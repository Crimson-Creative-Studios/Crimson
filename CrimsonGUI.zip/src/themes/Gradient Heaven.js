clearColor()
document.getElementById("element").value = ""
document.getElementById("backgroundmainchange").value = 'url("../backgrounds/gradienthevimg.png")'
document.getElementById("backgroundaltchange").value = 'transparent'
document.getElementById("textmainchange").value = "white"
document.getElementById("textaltchange").value = "#c4c4c4"
document.getElementById("buttonmainchange").value = "black"
document.getElementById("buttonhovchange").value = "#222"
document.getElementById("buttonactchange").value = "#444"
document.getElementById("buttonhovactchange").value = "#666"
loadColors()