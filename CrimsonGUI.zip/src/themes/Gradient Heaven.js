clearColor()

resetEl()

setBackgroundColor({
    main: 'url("../backgrounds/gradienthevimg.png")',
    alt: "rgba(0,0,0,0)",
    console: ""
})

setButtonColor({
    main: "#000000",
    hover: "#222222",
    active: "#444444",
    hoveractive: "#666666",
    text: ""
})

loadColors()