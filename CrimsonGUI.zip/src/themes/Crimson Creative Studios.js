clearColor()

resetEl()

setBackgroundColor({
    main: "#4d0025",
    alt: "rgba(0,0,0,0.075)",
    console: "var(--buttonact)"
})

setButtonColor({
    main: "#bd0a0a",
    hover: "#aa0808",
    active: "#970808",
    hoveractive: "#840707",
    text: ""
})

loadColors()