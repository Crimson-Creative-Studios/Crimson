clearColor()

document.getElementById("element").value = ""
document.getElementById("backgroundmainchange").value = "#000000"
document.getElementById("backgroundaltchange").value = "#000000"
document.getElementById("textmainchange").value = "white"
document.getElementById("textaltchange").value = "#c4c4c4"
document.getElementById("buttonmainchange").value = ""
document.getElementById("buttonhovchange").value = ""
document.getElementById("buttonactchange").value = ""
document.getElementById("buttonhovactchange").value = ""
loadColors()