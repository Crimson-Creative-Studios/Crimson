clearColor()

resetEl()

setBackgroundColor({
    main: "#000000",
    alt: "#000000",
    console: "#000000"
})

loadColors()