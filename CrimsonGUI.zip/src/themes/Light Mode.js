clearColor()

document.getElementById("element").value = ""
document.getElementById("backgroundmainchange").value = "#ffffff"
document.getElementById("backgroundaltchange").value = "#eeeeee"
document.getElementById("textmainchange").value = "black"
document.getElementById("textaltchange").value = "#3b3b3b"
document.getElementById("buttonmainchange").value = "#cc0c39"
document.getElementById("buttonhovchange").value = "#e80e41"
document.getElementById("buttonactchange").value = "#f22152"
document.getElementById("buttonhovactchange").value = "#f43d67"
loadColors()