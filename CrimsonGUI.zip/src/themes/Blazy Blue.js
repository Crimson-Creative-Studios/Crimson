clearColor()

resetEl()

setBackgroundColor({
    main: "#0084b8",
    alt: "#0079a8",
    console: "var(--buttonact)"
})

setButtonColor({
    main: "#cc5602",
    hover: "#ba4d00",
    active: "#ad4800",
    hoveractive: "#9c4100",
    text: ""
})

loadColors()