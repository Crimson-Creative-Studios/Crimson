clearColor()

resetEl()

setBackgroundColor({
    main: "#04c4ca",
    alt: "#16bdc9",
    console: "var(--button)"
})

setButtonColor({
    main: "#f7bb77",
    hover: "#dc9c56",
    active: "#c28142",
    hoveractive: "#ad7239",
    text: ""
})

loadColors()