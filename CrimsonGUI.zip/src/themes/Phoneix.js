clearColor()
document.getElementById("element").value = ""
document.getElementById("backgroundmainchange").value = "#04C4CA"
document.getElementById("backgroundaltchange").value = "#16bdc9"
document.getElementById("textmainchange").value = "white"
document.getElementById("textaltchange").value = "#c4c4c4"
document.getElementById("buttonmainchange").value = "#F7BB77"
document.getElementById("buttonhovchange").value = "#DC9C56"
document.getElementById("buttonactchange").value = "#C28142"
document.getElementById("buttonhovactchange").value = "#AD7239"
loadColors()