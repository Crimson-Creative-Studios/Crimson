clearColor()

document.getElementById("element").value = ""
document.getElementById("backgroundmainchange").value = "#503624"
document.getElementById("backgroundaltchange").value = "#4d3322"
document.getElementById("textmainchange").value = "white"
document.getElementById("textaltchange").value = "#c4c4c4"
document.getElementById("buttonmainchange").value = "#77AB43"
document.getElementById("buttonhovchange").value = "#628f35"
document.getElementById("buttonactchange").value = "#4b7025"
document.getElementById("buttonhovactchange").value = "#3f611d"
loadColors()