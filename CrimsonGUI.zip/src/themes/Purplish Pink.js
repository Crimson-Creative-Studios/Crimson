clearColor()

resetEl()

setBackgroundColor({
    main: "#db42c9",
    alt: "#d936c6",
    console: "var(--button)"
})

setButtonColor({
    main: "#af2ad4",
    hover: "#9f21c2",
    active: "#901cb0",
    hoveractive: "#7f169c",
    text: ""
})

loadColors()