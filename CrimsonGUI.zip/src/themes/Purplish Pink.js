clearColor()

document.getElementById("element").value = ""
document.getElementById("backgroundmainchange").value = "#e88bdd"
document.getElementById("backgroundaltchange").value = "#db7fd0"
document.getElementById("textmainchange").value = "white"
document.getElementById("textaltchange").value = "#c4c4c4"
document.getElementById("buttonmainchange").value = "#af2ad4"
document.getElementById("buttonhovchange").value = "#9f21c2"
document.getElementById("buttonactchange").value = "#901cb0"
document.getElementById("buttonhovactchange").value = "#7f169c"
loadColors()