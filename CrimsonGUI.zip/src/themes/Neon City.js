clearColor()

resetEl()

setBackgroundColor({
    main: "#dd00dd",
    alt: "#cc00cc",
    console: "var(--button)"
})

setButtonColor({
    main: "#00cccc",
    hover: "#00aaaa",
    active: "#008888",
    hoveractive: "#006363",
    text: ""
})

loadColors()