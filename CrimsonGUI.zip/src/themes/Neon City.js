clearColor()
document.getElementById("element").value = ""
document.getElementById("backgroundmainchange").value = "#730073"
document.getElementById("backgroundaltchange").value = "#6e006e"
document.getElementById("textmainchange").value = "white"
document.getElementById("textaltchange").value = "#c4c4c4"
document.getElementById("buttonmainchange").value = "#00a3a3"
document.getElementById("buttonhovchange").value = "#008c8c"
document.getElementById("buttonactchange").value = "#007a7a"
document.getElementById("buttonhovactchange").value = "#006363"
loadColors()