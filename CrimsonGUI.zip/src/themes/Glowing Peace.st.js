clearColor()

resetEl()

setBackgroundColor({
    main: 'radial-gradient(circle at var(--val1) var(--val2), rgba(189, 10, 10, 0.5) 0%, rgba(0, 0, 0, 0.0)) 50%',
    alt: "rgba(255,255,255,0.015)",
    console: ""
})

setButtonColor({
    main: "rgba(0,0,0,0.1)",
    hover: "rgba(0,0,0,0.2)",
    active: "rgba(0,0,0,0.3)",
    hoveractive: "rgba(0,0,0,0.4)",
    text: ""
})

document.documentElement.style.setProperty("--val1", "0px")
document.documentElement.style.setProperty("--val2", "0px")

loadColors()

window.onmousemove = function (e) {
    document.documentElement.style.setProperty("--val1", String(e.clientX) + "px")
    document.documentElement.style.setProperty("--val2", String(e.clientY) + "px")
}