const command = require("./deploy-commands")

command.deploy([])